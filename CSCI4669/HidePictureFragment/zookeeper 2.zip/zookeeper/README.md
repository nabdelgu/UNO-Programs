**Code Challenge: Zookeeper**
---------------------------------------

Challenge Overview
------------------

**Your response to this challenge can be used to supplement your SWEAP application. If you plan to complete this challenge for SWEAP, ensure you meet the other minimum requirements by visiting [here](http://gecapital.com/sweap "SWEAP Home Page"). Whether you apply or not, you are welcome to fork this repository and complete as a personal project challenge.**


Your local zoo has decided to undergo major renovations, and you have been hired as head zookeeper. You can delegate feeding, watering, washing, and playing with the animals to the interns, but you are responsible for keeping tabs on every animal in your zoo. Your task is to create a ledger that keeps track of the current animals the zoo owns. Animals can be added or removed from the list.


**The Basics:**
  
  - You may use *almost any* programming language... it's your choice.  See the supported options [here](http://ideone.com/).
  - You must keep track of the current animals in the zoo.
  - The ledger should be controlled through the command line. 
  - Each animal should have its own “entry” in the ledger. This entry should contain the animal’s name, species, and identification number. 
  - The identification number should be treated as the primary key for the program. 
  - When an animal leaves the zoo, its entry should be totally removed from the ledger.
  - When an animal is acquired, a new entry should be added to the ledger. 
  - You should be able to populate your ledger from an existing saved file, or save the ledger to a new file. The saved files should be in CSV format - see the sample data for examples. 
  - The program should have appropriate error handling and messages displayed if the user provides faulty input. 



**Basic Input/Output:**
 
  - Name your program as follows: `zookeeper.xx` (where xx is variable based on the language you choose)
  - Your program should be started from the command line. Starting the program should initialize a loop that continuously waits for user input, handles the input, then waits again.
  - You should be able to populate the ledger from a saved file:
    - `open <filename>`
    - The saved file should be a comma-separated list in the format `id,"animal's name","animal's species"`.  Note the quotes surrounding the name and species. You may append additional information after the species, if you wish to extend the program. However, the first three values MUST be those listed above.
  - You should be able to add an animal to the ledger:
    - `add "<name>" "<species>" [optional id number]`
    - Note: both the name and species are enclosed in quotes.
    - The id can be supplied when adding a new animal to the zoo, but it should behave just like a typical primary key: no duplicates, greater than 0, etc. If the id is not supplied, then it should be generated. 
  - You should be able to remove an animal from the ledger:
    - `remove <id number>`
  - You should be able to see all entries in the ledger, where each entry is on a new line:
    - `list`
    - The output of should start with the columns `id name species` in that order.  You may append additional information after the species, if you wish.
  - You should be able to save the ledger to a text file that can later be read by the program:
    - `save <filename>`
    - The saved file should be in the same format defined above in the instructions for `open`.
  - You should be able to exit the program safely:
    - `exit`
  - our program should output to the console.


_In this git repo, you will find a sample input and some steps you can follow to ensure your program is working as expected._


  **Bonus/Extensions:**
The requirements listed above are very basic. There are lots of ways this program could be extended, and any of them would impress us. For example, you could consider making each animal its own class with methods, e.g. have a speak method that writes a different “sound” to the output for each animal, that can be controlled from the interface. You could save the date or time when each animal was added. You could provide analytics on the animals currently owned by the zoo. You could implement an interactive interface that prompts you and provides menus of options. You could keep track of all the animals that are no longer with the zoo. You could provide functionality to sort and search the animals. There are tons of ways to personalize and improve your program! Just be sure to clearly document whatever you do so that we’ll be able to follow it. 



What to do
----------
1. [Download](http://git-scm.com/downloads) & install Git on your machine

2. <a href="https://gitlab.cs.uno.edu/sweap/zookeeper/fork" class="btn grouped" data-method="POST" rel="nofollow" title="Fork">Fork</a> this project - Go [here](https://gitlab.cs.uno.edu/sweap/zookeeper) and click the "Fork" button (located on the upper-right side of the screen)
  - WARNING: forked repositories are public by default.  If you don't want your fellow applicants to be able to see your code, make sure to make your fork private.

2. Clone your new fork'd repository to your local machine - `git clone https://gitlab.cs.uno.edu/YOUR_USERNAME_HERE/zookeeper.git`
3. Complete the code challenge and fill out the Quick Start & Questions in the the README (see below)
4. `git add` and `git commit` your local repository as you go
4. Push your code and README back to UNO's GitLab occasionally - `git push origin master`
5. Email [serp@ge.com](mailto:serp@ge.com) with the Commit URL to your fork'd repository that you want reviewed. It should include at least 2 files: (1) your updated README with Coding Questions answered, and (2) your program (zookeeper.xx)
   - Grant the "SWEAP" user "MASTER"-level access to your repository by going here `https://gitlab.cs.uno.edu/YOUR_USERNAME_HERE/zookeeper/team` and clicking the "New Team Member" button.
   - Then go here: `https://gitlab.cs.uno.edu/YOUR_USERNAME_HERE/zookeeper/commits/master`
   - Find the commit that you'd like us to review.  _The commit date must be on or before 11:59pm (central) on Oct-19!_
       - Click the "Browse Code ->" link for that commit
   - Copy and paste the URL into the email along with your name... it should look something like this:
       - `https://gitlab.cs.uno.edu/YOUR_USERNAME_HERE/zookeeper/tree/73afe0c8fe2...hash.hash...e80afea72b6`

_Note: If you have any questions, email [serp@ge.com](mailto:serp@ge.com).  I will do my best to respond to any questions Saturday & Sunday evening._

Judging Criteria
----------------

Your responses to the **Coding Questions** at the bottom of this README are the *Most Important* part of this challenge.  In addition to these question responses, your code will be assessed on quality, structure, and function (and how well you follow instructions). Remember, we don't expect you to be expert programmers (just yet)... We want to see how you think through a problem.  


For completion by applicant
===========================

Quick Start
-----------

* Replace this text with instructions on how to execute your program
* In just a few sentences, what programming language did you use and why? See [here](http://ideone.com/) for the supported ones. This is because I have taken a couple java classes. Also I used it because it the is the language that I have the most experience with.
* Also tell us anything else the reviewer should know about your code
My compilable code is located at zookeeper.java/src/zookeeper/java in my repository.

Coding Questions
----------------

Question 1: "How did you approach the problem?" (500 words or less)	Before I started coding, I first read and summarized the instructions. Using this, I researched the best methodology to approach the problem and the best data structures to use. This project enabled me to learn new Java concepts that I have never used before. I accomplished this by using my Java textbook, using the Internet, and code from some of my previous projects. This planning enabled me to re-use code I have already developed and helped me take an appropriate approach to this program.	When I started coding, I first created an animal object with name and species attributes. Then I built a skeleton of my zookeeper class program, which included all the methods and variables I thought would be needed. At this point, I had a basic idea of everything that I needed to do to make the program work. From here, the project went smoother than I anticipated. I then worked on the methods and tested them in my Main method until I got them to work properly. Once this was done, I moved on to my Main.	My Main method’s basic construct was a While Loop that continually calls my methods upon the user’s request. The Main builds an appropriate way to interact with the user. Then, I tested the edge cases and worked out the bugs. Finally, I investigated how to improve the user’s interaction through the command line.I learned from my past experiences how to better approach this program, which was definitely key to completing my project.



Question 2: "What was the most difficult aspect of the solution?" (500 words or less)
	The most difficult aspect was reading and writing from a file. This issueencompassed the majority of my time. When I first started, I had no idea how toappend out the commas and quotes in the text file when reading it in. I had thesame issue writing back into the file in the right format. I had to acquire newknowledge to get past this problem.	When reading into a file, appending out the commas was not difficult.This required me to do some research until I finally found out the right approachto take. What worked for me was using Substrings and then passing them thearguments index one and the length minus one to get rid of the quotes. Thissolved my issue and was beneficial because I learned about a new method that Icould use in the future. Next, I had to deal with writing to a file. This made melearn about the Print Writer. After this, the next problem I encountered wastacking on the commas, and the quotes. I solved this problem whileconcatenating a string and passing it into the Print Writer.	Except for the above-mentioned issues, almost everything else was nottremendously difficult. Object-Oriented Programming techniques learned in ourSoftware Engineering programming sequence at UNO gave me the knowledgeand experience necessary to complete my project.	
