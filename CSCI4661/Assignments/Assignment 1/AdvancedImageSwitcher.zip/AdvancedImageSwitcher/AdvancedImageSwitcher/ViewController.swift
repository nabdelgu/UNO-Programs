//
//  ViewController.swift
//  AdvancedImageSwitcher
//
//  Created by Noah on 2/20/15.
//  Copyright (c) 2015 Noah. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    @IBOutlet weak var imageButton: UIButton!
    @IBOutlet weak var imageSlider: UISlider!
    @IBOutlet weak var imageLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func onClick(sender: AnyObject) {
        imageView.image = UIImage(named: "Cat2")
        imageLabel.text = "Cat2"
        imageSlider.value = 0;
    }
    
    @IBAction func onSlide(sender: AnyObject) {
    
        var currentValue = Int(imageSlider.value)
        
        if(currentValue == 0){
            imageView.image = UIImage(named: "Cat2")
            imageLabel.text = "Cat2"
        }
        else if( currentValue == 1){
            imageView.image = UIImage(named: "Dog1")
             imageLabel.text = "Dog1"
        }
        else if( currentValue == 2){
             imageView.image = UIImage(named: "Dog2")
             imageLabel.text = "Dog2"
        }
        else if( currentValue == 3){
             imageView.image = UIImage(named: "Rabbit")
             imageLabel.text = "Rabbit"
        }
        else{
             imageView.image = UIImage(named: "Cat1")
             imageLabel.text = "Cat1"
        }
        
    }
    
   
        
    }
    
    
    


